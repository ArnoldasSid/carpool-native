Thanks for visiting MaterialDesignIcons.com
Check back often for new icons and follow @MaterialIcons for updates.

Icon: target
By: Doug C. Hardester